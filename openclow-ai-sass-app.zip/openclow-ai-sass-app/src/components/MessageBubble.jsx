'use client';

import { Bot, User } from 'lucide-react';

/* ─────────────────────────────────────────────────────────────
   MessageBubble
   Renders a single chat message — user or assistant.
   Shows a blinking cursor when AI is still streaming.
───────────────────────────────────────────────────────────── */
export default function MessageBubble({ message, isLast, isLoading }) {
  const isUser = message.role === 'user';
  const isStreaming = isLast && isLoading && !isUser;
  const isEmpty = message.content === '' && isStreaming;

  return (
    <div className={`flex gap-3 animate-fade-in ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
      {/* Avatar */}
      {!isUser && (
        <div className="flex-shrink-0 w-8 h-8 rounded-xl bg-brand-100 dark:bg-brand-600/20 flex items-center justify-center mt-0.5">
          <Bot className="w-4 h-4 text-brand-600 dark:text-brand-400" />
        </div>
      )}

      {/* Bubble */}
      <div className={isUser ? 'msg-user' : ''}>
        {isUser ? (
          <p className="text-sm leading-relaxed">{message.content}</p>
        ) : (
          <div className={`msg-ai ${isStreaming ? 'cursor-blink' : ''}`}>
            {isEmpty ? (
              /* Thinking dots when AI hasn't output anything yet */
              <span className="flex items-center gap-1 h-5">
                {[0, 1, 2].map((i) => (
                  <span
                    key={i}
                    className="w-1.5 h-1.5 rounded-full bg-zinc-400 dark:bg-zinc-500 animate-blink"
                    style={{ animationDelay: `${i * 0.15}s` }}
                  />
                ))}
              </span>
            ) : (
              message.content
            )}
          </div>
        )}
      </div>
    </div>
  );
}
