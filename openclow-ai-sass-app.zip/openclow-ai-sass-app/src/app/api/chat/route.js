import OpenAI from 'openai';

/* ─────────────────────────────────────────────────────────────
   POST /api/chat
   Body: { messages: [{ role, content }] }

   Uses DeepSeek's OpenAI-compatible API.
   Streams the response back as plain text chunks.
───────────────────────────────────────────────────────────── */

const client = new OpenAI({
  baseURL: 'https://api.deepseek.com',
  apiKey: process.env.DEEPSEEK_API_KEY,
});

const SYSTEM_PROMPT = `You are a helpful, knowledgeable, and friendly AI assistant. 
You provide clear, accurate, and concise responses. 
If you don't know something, say so honestly.
Format your responses naturally — use paragraphs, bullet points, or code blocks when appropriate.`;

export async function POST(req) {
  try {
    const { messages } = await req.json();

    if (!messages || !Array.isArray(messages)) {
      return new Response(
        JSON.stringify({ error: 'Invalid messages format' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    // Create streaming completion via DeepSeek
    const stream = await client.chat.completions.create({
      model: 'deepseek-chat',
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        ...messages,
      ],
      stream: true,
      max_tokens: 4096,
      temperature: 0.7,
    });

    // Pipe DeepSeek stream → Response stream
    const encoder = new TextEncoder();

    const readable = new ReadableStream({
      async start(controller) {
        try {
          for await (const chunk of stream) {
            const content = chunk.choices[0]?.delta?.content;
            if (content) {
              controller.enqueue(encoder.encode(content));
            }
          }
        } catch (err) {
          controller.error(err);
        } finally {
          controller.close();
        }
      },
    });

    return new Response(readable, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache',
        'X-Accel-Buffering': 'no', // Disable nginx buffering if used
      },
    });
  } catch (error) {
    console.error('[/api/chat] Error:', error);

    const message =
      error?.status === 401
        ? 'Invalid DeepSeek API key. Check your .env.local file.'
        : error?.message || 'Something went wrong.';

    return new Response(JSON.stringify({ error: message }), {
      status: error?.status || 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}
